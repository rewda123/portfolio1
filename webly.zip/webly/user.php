<?php
require 'connection.php';
session_start();

// Ensure only logged-in users can access
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "user") {
    header("Location: login.php");
    exit();
}

// Fetch all videos
$videos = $conn->query("SELECT * FROM videos ORDER BY uploaded_at DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2 class="text-center">Welcome, <?= htmlspecialchars($_SESSION["username"]) ?>!</h2>

    <h4 class="mt-4">Available Videos</h4>
    <table class="table table-bordered">
        <tr>
            <th>Title</th>
            <th>Video</th>
        </tr>
        <?php foreach ($videos as $video) : ?>
            <tr>
                <td><?= htmlspecialchars($video["title"]) ?></td>
                <td><a href="<?= htmlspecialchars($video["video_url"]) ?>" target="_blank" class="btn btn-primary">Watch</a></td>
            </tr>
        <?php endforeach; ?>
    </table>

    <h4 class="mt-4">Chat with Admin</h4>
    <a href="chat.php" class="btn btn-primary">Go to Chat</a>

    <p class="mt-3"><a href="logout.php">Logout</a></p>
</body>
</html>
