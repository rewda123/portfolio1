<?php
require 'connection.php';
session_start();

// Ensure only logged-in users can access chat
if (!isset($_SESSION["user_id"])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION["user_id"];
$user_role = $_SESSION["role"];

// Handle message sending
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["message"])) {
    $message = trim($_POST["message"]);
    $receiver_id = $_POST["receiver_id"] ?? null; // Default to null if not set

    if (!empty($message) && !empty($receiver_id)) {
        $stmt = $conn->prepare("INSERT INTO chats (sender_id, receiver_id, message) VALUES (?, ?, ?)");
        $stmt->execute([$user_id, $receiver_id, $message]);
    }
}

// Fetch chat messages
if ($user_role === "admin") {
    // Admin sees messages from all users
    $stmt = $conn->prepare("SELECT chats.*, users.username AS sender_name 
                            FROM chats 
                            JOIN users ON chats.sender_id = users.id 
                            ORDER BY sent_at ASC");
    $stmt->execute();
} else {
    // Users only see their own chats with the admin
    $stmt = $conn->prepare("SELECT * FROM chats WHERE sender_id = ? OR receiver_id = ? ORDER BY sent_at ASC");
    $stmt->execute([$user_id, $user_id]);
}

$messages = $stmt->fetchAll();

// Fetch all users (for admin to select)
$users = [];
if ($user_role === "admin") {
    $users = $conn->query("SELECT id, username FROM users WHERE role='user'")->fetchAll();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chat</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2 class="text-center">Chat</h2>

    <div class="chat-box border p-3 mb-3" style="height: 300px; overflow-y: scroll;">
        <?php foreach ($messages as $msg) : ?>
            <p><strong><?= ($msg["sender_id"] == $user_id) ? "You" : htmlspecialchars($msg["sender_name"] ?? "Admin") ?>:</strong> 
                <?= htmlspecialchars($msg["message"]) ?>
            </p>
        <?php endforeach; ?>
    </div>

    <form method="POST" action="chat.php">
        <?php if ($user_role === "admin") : ?>
            <select name="receiver_id" class="form-select mb-2" required>
                <option disabled selected>Select user</option>
                <?php foreach ($users as $user) : ?>
                    <option value="<?= $user["id"] ?>"><?= htmlspecialchars($user["username"]) ?></option>
                <?php endforeach; ?>
            </select>
        <?php else : ?>
            <input type="hidden" name="receiver_id" value="1"> <!-- Assume Admin ID = 1 -->
        <?php endif; ?>

        <div class="mb-3">
            <textarea name="message" class="form-control" placeholder="Type your message..." required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Send</button>
    </form>

    <p class="mt-3"><a href="<?= ($user_role === "admin") ? "admin.php" : "user.php" ?>">Back to Dashboard</a></p>
</body>
</html>
