<?php
require 'connection.php';
session_start();

// Ensure only admins can access this page
if (!isset($_SESSION["user_id"]) || $_SESSION["role"] !== "admin") {
    header("Location: login.php");
    exit();
}

// Handle video upload
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["add_video"])) {
    $title = trim($_POST["title"]);
    $video_url = trim($_POST["video_url"]);

    if (!empty($title) && !empty($video_url)) {
        $stmt = $conn->prepare("INSERT INTO videos (title, video_url) VALUES (?, ?)");
        $stmt->execute([$title, $video_url]);
    }
}

// Handle video deletion
if (isset($_GET["delete"])) {
    $video_id = $_GET["delete"];
    $stmt = $conn->prepare("DELETE FROM videos WHERE id = ?");
    $stmt->execute([$video_id]);
    header("Location: admin.php");
    exit();
}

// Handle video title update
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["edit_video"])) {
    $video_id = $_POST["video_id"];
    $new_title = trim($_POST["new_title"]);

    if (!empty($new_title)) {
        $stmt = $conn->prepare("UPDATE videos SET title = ? WHERE id = ?");
        $stmt->execute([$new_title, $video_id]);
    }
    header("Location: admin.php");
    exit();
}

// Fetch all videos
$videos = $conn->query("SELECT * FROM videos ORDER BY uploaded_at DESC")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="container mt-5">
    <h2 class="text-center">Admin Dashboard</h2>

    <h4 class="mt-4">Upload Video</h4>
    <form method="POST" action="admin.php" class="mb-4">
        <div class="mb-3">
            <label>Title:</label>
            <input type="text" name="title" class="form-control" required>
        </div>
        <div class="mb-3">
            <label>Video URL:</label>
            <input type="text" name="video_url" class="form-control" required>
        </div>
        <button type="submit" name="add_video" class="btn btn-success">Upload</button>
    </form>

    <h4>Uploaded Videos</h4>
    <table class="table table-bordered">
        <tr>
            <th>Title</th>
            <th>Video URL</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($videos as $video) : ?>
            <tr>
                <td><?= htmlspecialchars($video["title"]) ?></td>
                <td><a href="<?= htmlspecialchars($video["video_url"]) ?>" target="_blank">Watch</a></td>
                <td>
                    <a href="admin.php?delete=<?= $video["id"] ?>" class="btn btn-danger btn-sm">Delete</a>
                    
                    <!-- Edit Button (Opens Modal) -->
                    <button class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#editModal<?= $video["id"] ?>">Edit</button>
                    
                    <!-- Edit Modal -->
                    <div class="modal fade" id="editModal<?= $video["id"] ?>" tabindex="-1" aria-labelledby="editModalLabel" aria-hidden="true">
                        <div class="modal-dialog">
                            <form method="POST" action="admin.php" class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="editModalLabel">Edit Video Title</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                </div>
                                <div class="modal-body">
                                    <input type="hidden" name="video_id" value="<?= $video["id"] ?>">
                                    <label>New Title:</label>
                                    <input type="text" name="new_title" class="form-control" value="<?= htmlspecialchars($video["title"]) ?>" required>
                                </div>
                                <div class="modal-footer">
                                    <button type="submit" name="edit_video" class="btn btn-primary">Save Changes</button>
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </td>
            </tr>
        <?php endforeach; ?>
    </table>

    <h4 class="mt-4">User Chat</h4>
    <a href="chat.php" class="btn btn-primary">Go to Chat</a>

    <p class="mt-3"><a href="logout.php">Logout</a></p>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
