<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Webly - Learn Better Web Development</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <a class="navbar-brand" href="index.php">Webly</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="register.php">Register</a></li>
                    <li class="nav-item"><a class="nav-link" href="login.php">Login</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Header -->
    <header class="bg-primary text-white text-center py-5">
        <h1>Welcome to Webly</h1>
        <p>Learn how to build better websites with our tutorials and resources.</p>
    </header>

    <!-- Blog Section -->
    <div class="container my-5">
        <h2 class="text-center">Latest Blogs</h2>
        <div class="row">
            <div class="col-md-4">
                <div class="card">
                    <img src="1.png" class="card-img-top" alt="Blog Image">
                    <div class="card-body">
                        <h5 class="card-title">Understanding HTML & CSS</h5>
                        <p class="card-text">Learn the fundamentals of HTML and CSS for building modern websites.</p>
                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="2.png" class="card-img-top" alt="Blog Image">
                    <div class="card-body">
                        <h5 class="card-title">PHP & MySQL for Beginners</h5>
                        <p class="card-text">Discover how to use PHP and MySQL to create dynamic web applications.</p>
                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card">
                    <img src="3.png" class="card-img-top" alt="Blog Image">
                    <div class="card-body">
                        <h5 class="card-title">Bootstrap for Responsive Design</h5>
                        <p class="card-text">Learn how Bootstrap makes web design easier and more responsive.</p>
                        <a href="#" class="btn btn-primary">Read More</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Photo Section -->
    <div class="container my-5">
        <h2 class="text-center">Photo Gallery</h2>
        <div class="row">
            <div class="col-md-4"><img src="4.png" class="img-fluid rounded"></div>
            <div class="col-md-4"><img src="5.png" class="img-fluid rounded"></div>
            <div class="col-md-4"><img src="6.png" class="img-fluid rounded"></div>
        </div>
    </div>

    <!-- About Us Section -->
    <div class="container my-5">
        <h2 class="text-center">About Webly</h2>
        <p class="text-center">Webly is a platform designed to help aspiring web developers learn best practices for building better websites. Our tutorials cover HTML, CSS, JavaScript, PHP, and more.</p>
    </div>

    <!-- Footer -->
    <footer class="bg-dark text-white text-center py-3">
        <p>&copy; 2025 Webly. All rights reserved.</p>
    </footer>
</body>
</html>
